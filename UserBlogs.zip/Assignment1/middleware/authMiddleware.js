const validateAuthorInput = (req, res, next) => {
    // Your validation logic for author input
    next();
  };
  
  module.exports = { validateAuthorInput };